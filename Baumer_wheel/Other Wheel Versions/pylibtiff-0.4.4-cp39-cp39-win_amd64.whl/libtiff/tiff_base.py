
class TiffBase:

    pass
