
# THIS FILE IS GENERATED FROM PYLIBTIFF SETUP.PY
short_version = '0.4.4'
version = '0.4.4'
full_version = '0.4.4'
git_revision = 'd801dfabec391c508f5e83e731836db54ac5a51f'
release = True
if not release:
    version = full_version
